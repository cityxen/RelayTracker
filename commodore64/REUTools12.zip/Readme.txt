REUTools 1.2 - by Walt of Bonzai
================================

As promised on the Mibri Demo Show ( https://www.youtube.com/watch?v=QY5zeV65ARc at 2:07:55), here is the REU tools :)

Included is also a small demo part that was scrapped from Expand. (Missing credit : Spindle loader and logo by LFT)

The tools are

* CheckChar ("CHARSTREAM CHECK")
* REUDetect ("DETECT AND TEST")
* SpriteTiming ("SPRITE TIMING")

The names in capital letters are the corresponding file names on the REUTools_BZ.d64 disk image.

The .prg files can be found in the REUTools subfolder.
The source files (Kick Assembler format) can be found in the Source subfolder.

The source code is released as-is for your edutainment. I release them in hope of more and better REU stuff in the future :)
After being part of this discussion https://csdb.dk/forums/?roomid=7&topicid=146244 I strongly hope that the makers of hardware
products such as C64 Ultimate, 1541 Ultimate and Chameleon will use the software supplied here to improve their products.


CheckChar
=========

Tests if streaming to char works as expected. Uses char to sprite collision check with a predefined test pattern.

Will fail on VICE x64 but not on VICE x64sc. Also fails on The C64 (See https://www.youtube.com/watch?v=UInN-ta9CkA for how-to)

The check is running every 8th frame so you can see what happens. If used in your own work, this should be changed.


REUDetect
=========

Detects if REU is present and its size. Tests the needed amount of memory (512KB, can be changed in the source code).


SpriteTiming
============

Tests by streaming to magic byte starting a few rasterlines before where 8 sprites is displayed. Uses char to sprite collision check
to detect where char position 0 is in the stream for the first and second line of the sprites.

Returned is the two values. A 3rd value is displayed, this is the number of cycles available per raster line with 8 sprites turned on,
calculated by subtracting value 1 from value 2.

The check is running every 8th frame so you can see what happens. If used in your own work, this should be changed.

This test was needed for the end part of Expand as it uses 8 sprites with magic byte overlay in the upper border. I noticed that between
different VICE versions, 1541 Ultimate and real REU (Thanks again, Hedning :)) the magic byte overlay was either displaced in X or a byte
too long or short per rasterline. These differences also explains the problem with (and the many versions of) the demo Treu Love by Booze Design.
(I would love if you guys released a 100% version using this check and the char streaming check ;))

If you have other REU compatible equipment/emulators not listed, please test and contact me for updating the list :)
Also contact me if you have any questions about the source code (I have tried to comment it...)

You can PM me on CSDB or mail to afogh@adslhome.dk


Changelog
=========
1.0      25-10-2020     Initial release

1.1      04-12-2020     Chameleon Beta-9j added to SpriteTiming. 
                        Documented the code in SpriteTiming.
                        Fixed timing in animation.

1.2      27-12-2020     Z64K Release 1.2.4 Build 20200716.1329 added to SpriteTiming.
                        Added REU detection to CheckChar and SpriteTiming.
                        Added support for NTSC, old NTSC and Drean machines (earlier versions are PAL only).


BONZAI - MORE THAN JUST A TREE
